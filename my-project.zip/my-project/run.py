import os
import sys

# Add backend folder to Python path
BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

BACKEND_DIR = os.path.join(
    BASE_DIR,
    "backend"
)

if BACKEND_DIR not in sys.path:
    sys.path.append(BACKEND_DIR)

from backend.app import app


if __name__ == "__main__":

    host = os.getenv(
        "HOST",
        "0.0.0.0"
    )

    port = int(
        os.getenv(
            "PORT",
            5000
        )
    )

    debug = os.getenv(
        "DEBUG",
        "True"
    ).lower() == "true"

    print("\n")
    print("=" * 50)
    print("AUTHENTIHIRE SERVER STARTING")
    print("=" * 50)
    print(f"Host   : {host}")
    print(f"Port   : {port}")
    print(f"Debug  : {debug}")
    print("=" * 50)
    print(
        f"Open: http://localhost:{port}"
    )
    print("=" * 50)
    print("\n")

    app.run(
        host=host,
        port=port,
        debug=debug
    )
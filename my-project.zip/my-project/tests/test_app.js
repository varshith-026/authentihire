// Basic test suite for my-project
// Add your test cases here

const assert = require('assert');

describe('App Tests', () => {
  it('should run without errors', () => {
    assert.ok(true);
  });
});

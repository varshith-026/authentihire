import random

def verify_speaker():

    similarity = round(
        random.uniform(70, 100),
        2
    )

    return {
        "matched": similarity > 85,
        "similarity": similarity
    }
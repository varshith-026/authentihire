def analyze_transcript(text):

    words = len(text.split())

    return {
        "word_count": words,
        "length": "short"
        if words < 20
        else "good"
    }
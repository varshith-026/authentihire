def estimate_confidence(text):

    words = len(text.split())

    score = min(
        100,
        words * 2
    )

    return score
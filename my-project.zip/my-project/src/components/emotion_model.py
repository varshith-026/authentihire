import random

def detect_emotion():

    emotions = [
        "neutral",
        "happy",
        "confident",
        "nervous",
        "stressed"
    ]

    return random.choice(emotions)
import random

def detect_eye_movement():

    directions = [
        "center",
        "left",
        "right",
        "down"
    ]

    direction = random.choice(directions)

    suspicious = direction != "center"

    return {
        "direction": direction,
        "suspicious": suspicious
    }
import random

def detect_emotion():

    emotions = [
        "neutral",
        "happy",
        "confident",
        "nervous",
        "stressed"
    ]

    emotion = random.choice(emotions)

    return {
        "emotion": emotion
    }
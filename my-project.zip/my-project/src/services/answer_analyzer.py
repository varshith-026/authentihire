def analyze_answer(answer_text):

    word_count = len(answer_text.split())

    confidence = min(
        100,
        word_count * 2
    )

    return {
        "word_count": word_count,
        "confidence_score": confidence
    }
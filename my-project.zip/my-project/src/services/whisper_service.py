def transcribe_audio(audio_path=None):

    """
    Placeholder for OpenAI Whisper.
    """

    return {
        "transcript":
        "This is a sample interview answer."
    }
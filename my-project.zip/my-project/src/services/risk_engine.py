def calculate_risk(
        eye_result,
        liveness_result
):

    risk = 0

    if eye_result["suspicious"]:
        risk += 20

    if not liveness_result["live"]:
        risk += 50

    return risk


def classify_risk(score):

    if score <= 30:
        return "SAFE"

    if score <= 60:
        return "SUSPICIOUS"

    return "HIGH_RISK"
def send_notification(
        email,
        subject,
        message
):

    print("EMAIL SENT")
    print("TO:", email)
    print("SUBJECT:", subject)
    print("MESSAGE:", message)

    return True
from flask import Blueprint, jsonify
import sqlite3
import os

reports_bp = Blueprint("reports", __name__)

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "..",
    "database",
    "authentihire.db"
)


@reports_bp.route("/report/<int:candidate_id>")
def report(candidate_id):

    conn = sqlite3.connect(DB_PATH)

    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM interviews
        WHERE candidate_id=?
        """,
        (candidate_id,)
    )

    data = cursor.fetchall()

    conn.close()

    return jsonify({
        "candidate_id": candidate_id,
        "reports": data
    })
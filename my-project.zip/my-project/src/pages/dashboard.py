from flask import Blueprint, jsonify
import sqlite3
import os

dashboard_bp = Blueprint("dashboard", __name__)

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "..",
    "database",
    "authentihire.db"
)


@dashboard_bp.route("/dashboard")
def dashboard():

    conn = sqlite3.connect(DB_PATH)

    cursor = conn.cursor()

    cursor.execute("""
    SELECT * FROM candidates
    """)

    rows = cursor.fetchall()

    conn.close()

    return jsonify(rows)
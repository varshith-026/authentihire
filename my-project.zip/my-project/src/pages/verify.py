from flask import Blueprint, jsonify
from services.face_service import verify_face

verify_bp = Blueprint("verify", __name__)


@verify_bp.route("/verify-face", methods=["POST"])
def verify():

    result = verify_face()

    return jsonify({
        "success": True,
        "verification": result
    })
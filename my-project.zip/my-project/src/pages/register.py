from flask import Blueprint, request, jsonify
import sqlite3
import os

register_bp = Blueprint("register", __name__)

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "..",
    "database",
    "authentihire.db"
)


@register_bp.route("/register", methods=["POST"])
def register():

    data = request.json

    name = data.get("name")
    email = data.get("email")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO candidates(name,email)
        VALUES(?,?)
        """,
        (name, email)
    )

    conn.commit()

    candidate_id = cursor.lastrowid

    conn.close()

    return jsonify({
        "success": True,
        "candidate_id": candidate_id
    })